module DeTai

export kiem_tra_dau_vao, giai_bai

"""
    kiem_tra_dau_vao(du_lieu)

TODO: thay bằng hợp đồng input của đúng phiếu đề tài: kiểu dữ liệu, kích thước,
chỉ số, ràng buộc và cách xử lý dữ liệu không hợp lệ. Không đọc tệp CSV.
Khung chưa có logic; không được ghi hàm này đã kiểm tra đạt.
"""
function kiem_tra_dau_vao(du_lieu)
    error("TODO: chua cai dat kiem tra input cho de tai ca nhan")
end

"""
    giai_bai(du_lieu)

TODO: tự cài đặt thuật toán đúng phiếu, mô tả cấu trúc dữ liệu và output.
Chỉ dùng mã BFS tham khảo cách tổ chức; không gán BFS cho đề tài khác.
"""
function giai_bai(du_lieu)
    error("TODO: chua cai dat thuat toan cua de tai ca nhan")
end

end # module DeTai
