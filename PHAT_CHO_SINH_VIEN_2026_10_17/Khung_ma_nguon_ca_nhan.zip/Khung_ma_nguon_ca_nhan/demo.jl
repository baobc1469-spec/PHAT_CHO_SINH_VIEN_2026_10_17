include(joinpath(@__DIR__, "src", "DeTai.jl"))
using .DeTai

# TODO: thay nothing bằng dữ liệu khai báo trực tiếp theo phiếu hoặc viết phần
# nhập bàn phím; in rõ input, output mong đợi, output thực tế và bước trung gian.
du_lieu = nothing
println("KHUNG CHUA HOAN THIEN: thay input va cai dat src/DeTai.jl truoc khi nop.")
ket_qua = giai_bai(du_lieu)
println(ket_qua)
