using Test
include(joinpath(@__DIR__, "..", "src", "DeTai.jl"))
using .DeTai

@testset "TODO - kiem thu de tai ca nhan" begin
    # TODO: thay khối error bằng ít nhất 12 ca có ID; ghi input, đáp án độc lập,
    # phép kiểm tra output/bất biến và đối chiếu bảng trong báo cáo.
    # Ca input sai có thể kiểm hàm validator; không buộc chạy vào thuật toán.
    error("TODO: chua co ca kiem thu; khung khong duoc bao Pass")
end
